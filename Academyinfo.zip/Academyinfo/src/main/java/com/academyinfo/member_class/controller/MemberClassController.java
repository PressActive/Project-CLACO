package com.academyinfo.member_class.controller;

public interface MemberClassController {

}
