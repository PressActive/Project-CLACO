package com.academyinfo.review.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/review")
@Controller
public class ReviewControllerImpl implements ReviewController {

}
