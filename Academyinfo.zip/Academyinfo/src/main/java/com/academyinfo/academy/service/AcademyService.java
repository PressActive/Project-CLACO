package com.academyinfo.academy.service;

public interface AcademyService {

}
