package com.academyinfo.Class.controller;

public interface ClassController {

}
