package com.academyinfo.board.alertboard.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.academyinfo.board.alertboard.domain.entity.AlertBoardEntity;
import com.academyinfo.board.comment.domain.entity.CommentEntity;
import com.academyinfo.member.domain.entity.MemberEntity;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@NoArgsConstructor
public class AlertBoardResponseDto {
	private int bindex;
	private String writer;
	private String title;
	private String contents;
	private LocalDateTime createdDate;
	private LocalDateTime modifiedDate;
	private int count;
	
	@Builder
	public AlertBoardResponseDto(int bindex, String title, String contents, String writer, int count, LocalDateTime createdDate, LocalDateTime modifiedDate, MemberEntity mindex, List<CommentEntity> cmtindex) {
		this.bindex = bindex;
		this.writer = writer;
		this.title = title;
		this.contents = contents;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.count = count;
	}
	
	@Builder
	public AlertBoardResponseDto(AlertBoardEntity alertBoardEntity) {
		this.bindex = alertBoardEntity.getBindex();
		this.writer = alertBoardEntity.getWriter();
		this.title = alertBoardEntity.getTitle();
		this.contents = alertBoardEntity.getContents();
		this.createdDate = alertBoardEntity.getCreatedDate();
		this.modifiedDate = alertBoardEntity.getModifiedDate();
		this.count = alertBoardEntity.getCount();
	}
}
