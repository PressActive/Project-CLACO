package com.academyinfo.image.academy.controller;

public interface AcademyImageController {

}
