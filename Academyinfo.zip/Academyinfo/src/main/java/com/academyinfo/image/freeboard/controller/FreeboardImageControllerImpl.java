package com.academyinfo.image.freeboard.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/image")
@Controller
public class FreeboardImageControllerImpl implements FreeboardImageController {

}
