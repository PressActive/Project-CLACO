package com.academyinfo.image.freeboard.files;

public enum FileType {
	IMAGE, GENERAL
}