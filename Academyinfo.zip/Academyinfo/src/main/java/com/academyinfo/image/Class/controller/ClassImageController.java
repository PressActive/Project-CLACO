package com.academyinfo.image.Class.controller;

public interface ClassImageController {

}
