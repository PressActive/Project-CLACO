package com.academyinfo.Files.Class.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/image/class")
@Controller
public class ClassImageControllerImpl implements ClassImageController {

}
