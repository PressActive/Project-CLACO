package com.academyinfo.Files.Class.controller;

public interface ClassImageController {

}
