package com.academyinfo.Files.Class.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.academyinfo.Class.domain.entity.ClassEntity;
import com.academyinfo.Class.dto.ClassResponseDto;
import com.academyinfo.Files.Class.domain.entity.ClassFilesEntity;
import com.academyinfo.Files.Class.domain.repository.ClassFilesRepository;
import com.academyinfo.Files.Class.dto.ClassFilesRequestDto;
import com.academyinfo.Files.Class.dto.ClassFilesResponseDto;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class ClassFilesServiceImpl implements ClassFilesService {
	private ClassFilesRepository classFilesRepository;
	
	@Transactional
	public void save(ClassEntity classEntity, ClassFilesRequestDto cfDto) {
		cfDto.setCindex(classEntity);
		
		ClassFilesEntity cfEntity = cfDto.toEntity();
		classFilesRepository.save(cfEntity);
	}
	
	@Transactional
	public void delete(ClassFilesRequestDto cfDto) {
		ClassFilesEntity cfEntity = cfDto.toEntity();
		classFilesRepository.delete(cfEntity);
	}
	
	// 메인페이지 추천강의 이미지 N개 출력
	@Transactional(readOnly = true)
	public List<ClassFilesResponseDto> getImage(List<ClassResponseDto> listClass){
		List<ClassFilesResponseDto> classFilesDtoList = new ArrayList<>();
		
		if (listClass == null || listClass.isEmpty()) {
			return classFilesDtoList;
		}

	    for (ClassResponseDto classResponseDto : listClass) {
	        classFilesDtoList.add(classResponseDto.getIindex().get(0));
	    }
		
		return classFilesDtoList;
	}
	
	private ClassFilesResponseDto convertEntityToDto(ClassFilesEntity classFilesEntity) {
	    return new ClassFilesResponseDto(classFilesEntity);
	}
}
