package com.academyinfo.Files.Class.service;

import java.util.List;

import com.academyinfo.Files.Class.dto.ClassImageResponseDto;

public interface ClassImageService {
	public List<ClassImageResponseDto> getImage();
	public List<ClassImageResponseDto> search(String keyword);
}
