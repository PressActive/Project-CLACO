package com.academyinfo.Files.academy.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/image/academy")
@Controller
public class AcademyImageControllerImpl implements AcademyImageController {

}
