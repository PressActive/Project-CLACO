package com.academyinfo.Files.academy.controller;

public interface AcademyImageController {

}
