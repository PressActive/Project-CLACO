package com.academyinfo.Files.academy.dto;

import com.academyinfo.Files.academy.domain.entity.AcademyImageEntity;
import com.academyinfo.academy.domain.entity.AcademyEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class AcademyImageRequestDto {
	private int iindex;
	private String name;
	private String path;
	
	private AcademyEntity aindex;
	
	public AcademyImageEntity toEntity() {
		AcademyImageEntity imageEntity = AcademyImageEntity.builder()
				.iindex(iindex)
				.name(name)
				.path(path)
				.aindex(aindex)
				.build();
		
		return imageEntity;
	}
}
