package com.academyinfo.image.freeboard.controller;

public interface FreeboardImageController {

}
