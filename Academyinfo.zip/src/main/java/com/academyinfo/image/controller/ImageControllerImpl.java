package com.academyinfo.image.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/image")
@Controller
public class ImageControllerImpl implements ImageController {

}
