package com.academyinfo.board.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.academyinfo.member.domain.MemberEntity;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@Getter
@Entity
@Table(name = "comments")
public class CommentEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cmtindex;
	
	@Column(columnDefinition = "TEXT", nullable = false)
	private String comment; // 댓글 내용
	
	@Column(name = "created_date")
	@CreatedDate
	private LocalDateTime createdDate;
	@Column(name = "modified_date")
	@LastModifiedDate
	private LocalDateTime modifiedDate;
	
	@ManyToOne
	@JoinColumn(name = "bindex")
	private BoardEntity bindex;
	
	@ManyToOne
	@JoinColumn(name = "mindex")
	private MemberEntity mindex;
	
	@Builder
	public CommentEntity(int cmtindex, String comment, LocalDateTime createdDate, LocalDateTime modifiedDate, BoardEntity bindex, MemberEntity mindex) {
		this.cmtindex = cmtindex;
		this.comment = comment;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.bindex = bindex;
		this.mindex = mindex;
	}
}
