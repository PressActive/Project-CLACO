package com.academyinfo.board.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.academyinfo.board.dto.CommentRequestDto;
import com.academyinfo.board.service.CommentService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RequestMapping("/api")
@RestController
public class CommentController {
	private final CommentService commentService;
	
	/* CREATE */
	@PostMapping("/freeboard/post/{no}/comments")
	public ResponseEntity commentSave(@PathVariable int cmtindex, @RequestBody CommentRequestDto dto) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // 현재 로그인한 사용자의 정보를 가져온다
		String id = ((UserDetails)principal).getUsername(); // 사용자의 Id
		
		return ResponseEntity.ok(commentService.commentSave(id, cmtindex, dto));
	}
}
