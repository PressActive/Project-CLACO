package com.academyinfo.board.service;

import com.academyinfo.board.dto.CommentRequestDto;

public interface CommentService {
	public int commentSave(String name, int bindex, CommentRequestDto dto);
}
