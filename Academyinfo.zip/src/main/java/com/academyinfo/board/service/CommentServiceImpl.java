package com.academyinfo.board.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.academyinfo.board.domain.entity.BoardEntity;
import com.academyinfo.board.domain.entity.CommentEntity;
import com.academyinfo.board.domain.repository.BoardRepository;
import com.academyinfo.board.domain.repository.CommentRepository;
import com.academyinfo.board.dto.CommentRequestDto;
import com.academyinfo.member.domain.MemberEntity;
import com.academyinfo.member.repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class CommentServiceImpl implements CommentService {
	private final CommentRepository commentRepository;
	private final MemberRepository memberRepository;
	private final BoardRepository boardRepository;
	
	/* 댓글 생성 */
	@Transactional
	public int commentSave(String name, int bindex, CommentRequestDto dto) {
		Optional<MemberEntity> memberEntityWrapper = memberRepository.findById(name);
        MemberEntity member = memberEntityWrapper.get();
		BoardEntity board = boardRepository.findById(bindex).orElseThrow(() ->
		new IllegalArgumentException("댓글 쓰기 실패: 해당 게시글이 존재하지 않습니다." + bindex));
		dto.setBindex(board);
		dto.setMindex(member);
		CommentEntity comment = dto.toEntity();
		commentRepository.save(comment);
		
		return dto.getCmtindex();
	}
}
