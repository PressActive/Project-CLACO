package com.academyinfo.review.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.academyinfo.Class.domain.entity.ClassEntity;
import com.academyinfo.Class.domain.repository.ClassRepository;
import com.academyinfo.member.domain.entity.MemberEntity;
import com.academyinfo.member.domain.repository.MemberRepository;
import com.academyinfo.review.domain.entity.ReviewEntity;
import com.academyinfo.review.domain.repository.ReviewRepository;
import com.academyinfo.review.dto.ReviewRequestDto;
import com.academyinfo.review.dto.ReviewResponseDto;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class ReviewServiceImpl implements ReviewService {
	private ReviewRepository reviewRepository;
	private ClassRepository classRepository;
	private MemberRepository memberRepository;
	
	private static final int MAX_REPORT_COUNT = 5; // 허용 report 수
	
	//select * from review;
	@Transactional(readOnly = true)
	public List<ReviewResponseDto> getReview(){
		List<ReviewEntity> reviewEntities = reviewRepository.findAll();
		List<ReviewResponseDto> reviewDtoList = new ArrayList<>();
		
		if (reviewEntities.isEmpty()) {
	    	return reviewDtoList;
	    }

	    for (ReviewEntity reviewEntity : reviewEntities) {
	        reviewDtoList.add(this.convertEntityToDto(reviewEntity));
	    }
	    
		return reviewDtoList;
	}
	
	/* 최신 리뷰 순서로 정렬 검색 */
	@Transactional(readOnly = true)
	public List<ReviewResponseDto> getReviewByCreatedDate(){
		// reviewRepository.findOrderByCreatedDateDesc();
		Sort sort = Sort.by(
				Sort.Order.desc("createdDate")
				);
		
		
		List<ReviewEntity> reviewEntities = reviewRepository.findAll(sort);
		List<ReviewResponseDto> reviewDtoList = new ArrayList<>();
		
		if (reviewEntities.isEmpty()) {
	    	return reviewDtoList;
	    }

	    for (ReviewEntity reviewEntity : reviewEntities) {
	        reviewDtoList.add(this.convertEntityToDto(reviewEntity));
	    }
	    
		return reviewDtoList;
	}
	
	// 수강후기 생성
	@Transactional
	public int reviewSave(String id, int cindex, ReviewRequestDto dto) {
		Optional<MemberEntity> memberEntityWrapper = memberRepository.findById(id);
        MemberEntity member = memberEntityWrapper.get();
        
		ClassEntity classes = classRepository.findById(cindex).orElseThrow(() ->
		new IllegalArgumentException("댓글 쓰기 실패: 해당 강의가 존재하지 않습니다." + cindex));
		
		dto.setCindex(classes);
		dto.setMindex(member);
		ReviewEntity review = dto.toEntity();
		reviewRepository.save(review);
		
		return dto.getRvindex();
	}
	
	// 수강후기 수정
	@Transactional
	public void update(int rvindex, ReviewRequestDto dto) {
		ReviewEntity review = reviewRepository.findById(rvindex).orElseThrow(() ->
		new IllegalArgumentException("해당 수강후기가 존재하지 않습니다. " + rvindex));
		
		review.update(dto.getContents());
	}
	
	// 수강후기 권한 승인
	@Transactional
	public int updateStatus(int rvindex) {
		return reviewRepository.updateStatus(rvindex);
	}
	
	// 수강후기 삭제
	@Transactional
	public void delete(int rvindex) {
		ReviewEntity review = reviewRepository.findById(rvindex).orElseThrow(() ->
		new IllegalArgumentException("해당 수강후기가 존재하지 않습니다. id=" + rvindex));
		
		reviewRepository.delete(review);
	}
	
	// 신고 조건부 조회
	@Transactional(readOnly = true)
	public List<ReviewResponseDto> getReportReviewlist() {
		/* list를 읽어와서 표시(report용)
		 */
		
		List<ReviewEntity> reviewEntities = reviewRepository.findByReportGreaterThan(MAX_REPORT_COUNT); 
		List<ReviewResponseDto> reviewDtoList = new ArrayList<>();
		
		for ( ReviewEntity reviewEntity : reviewEntities ) {  
			// 정규식 for
			// 반복문으로 게시판 구성요소들을 불러와 리스트에 추가
			reviewDtoList.add(this.convertEntityToDto(reviewEntity));
		}
		
		return reviewDtoList;
	}
	
	private ReviewResponseDto convertEntityToDto(ReviewEntity reviewEntity) {
	    return new ReviewResponseDto(reviewEntity);
	}
	
	
}
