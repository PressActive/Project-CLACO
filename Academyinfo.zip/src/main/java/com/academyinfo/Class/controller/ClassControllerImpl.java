package com.academyinfo.Class.controller;

import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.academyinfo.Class.dto.ClassRequestDto;
import com.academyinfo.Class.dto.ClassResponseDto;
import com.academyinfo.Class.service.ClassService;
import com.academyinfo.board.freeboard.dto.BoardRequestDto;
import com.academyinfo.board.freeboard.dto.BoardResponseDto;
import com.academyinfo.review.dto.ReviewResponseDto;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/claco")
@Controller
public class ClassControllerImpl implements ClassController {
	private ClassService classService;
	
	@GetMapping("")
	public String list() {
		return "/search";
	}
	
	@GetMapping("/search")
	public String search(@RequestParam(value="keyword", required=false) String keyword, Model model) {
		List<ClassResponseDto> listFilter = classService.search(keyword);
		
		model.addAttribute("listFilter", listFilter);
		
		return "/claco/searchlist";
	}
	
	// 게시글 등록화면으로 이동
	@GetMapping("/post")
	public String write(Model model) {
		
		return "/claco/write";
	}
	
	/*
	
	// 게시글 등록화면에서 데이터 넘어오면 DB 저장
	@PostMapping("/post")
	public String write(ClassRequestDto classRequestDto) {
			
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // 현재 로그인한 사용자의 정보를 가져온다
		String id = ((UserDetails)principal).getUsername(); // 사용자의 Id
			
		classService.savePost(id, classRequestDto);
			
		return "redirect:/claco";
	}
	
	// 게시글 상세보기
	@GetMapping("/post/{no}")
	public String detail(@PathVariable("no") int no, Model model) {
		ClassResponseDto classDTO = classService.getPost(no);
		List<ReviewResponseDto> reviewList = classDTO.getReviews();
	        
		boolean isLogin = false;
	    boolean isWriter = false;
	    Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // 현재 로그인한 사용자의 정보를 가져온다
	        
	    // 로그인 상태 체크
	    if (!principal.toString().equals("anonymousUser")) {
	    	String id = ((UserDetails)principal).getUsername(); // 사용자의 Id
	    	
	    	isLogin = true;
	     	model.addAttribute("loginUser", id);
	     	
	       	// 게시글 작성자 본인확인
	       	if (classDTO.getMid().equals(id)) {
	       		isWriter = true;
	       	} 
	    }
	        
	    model.addAttribute("isLogin", isLogin);
	    model.addAttribute("isWriter", isWriter);
	        
	    // 댓글 관련 기능
	    if (reviewList != null && !reviewList.isEmpty()) {
	     	model.addAttribute("review", reviewList);
	       	model.addAttribute("reviewCnt", reviewList.size());
	    } else {
	    	model.addAttribute("reviewCnt", 0);
	    }
	        
	    model.addAttribute("classDto", classDTO);
	        
	    return "/claco/detail";
	}

	// 게시글 수정
	@GetMapping("/post/edit/{no}")
	public String edit(@PathVariable("no") int no, Model model) {
	    ClassResponseDto boardDTO = classService.getPost(no);
	    model.addAttribute("boardDto", boardDTO);
	        
	    return "/claco/update";
	}

	// 게시글 수정 값 DB 저장
	@PutMapping("/post/edit/{no}")
	public String update(ClassRequestDto classDTO) {
	   	
	 	Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // 현재 로그인한 사용자의 정보를 가져온다
		String id = ((UserDetails)principal).getUsername(); // 사용자의 Id
	  	
	    classService.savePost(id, classDTO);

	    return "redirect:/claco";
	}
	    
	// 게시글 삭제 실행
	@DeleteMapping("/post/{no}")
	public String delete(@PathVariable("no") int no) {
	    classService.deletePost(no);
	    
	    return "redirect:/claco";
	}
	
	*/
}
