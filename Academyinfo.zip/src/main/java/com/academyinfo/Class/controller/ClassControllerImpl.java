package com.academyinfo.Class.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/class")
@Controller
public class ClassControllerImpl implements ClassController {

}
