package com.academyinfo.academy.service;

import org.springframework.stereotype.Service;

import com.academyinfo.academy.domain.repository.AcademyRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class AcademyServiceImpl implements AcademyService {
	private AcademyRepository academyRepository;
}
