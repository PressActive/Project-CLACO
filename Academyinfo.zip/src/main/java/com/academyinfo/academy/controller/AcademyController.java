package com.academyinfo.academy.controller;

public interface AcademyController {

}
