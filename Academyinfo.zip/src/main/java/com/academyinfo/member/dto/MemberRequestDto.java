package com.academyinfo.member.dto;

import java.time.LocalDateTime;

import com.academyinfo.member.domain.entity.MemberEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class MemberRequestDto {
	// Member 관련 내용을 Service >> Entity 전달
	private Long mindex;
	private String id;
	private String pwd;
	private String name;
	private String phone;
	private String email;
	private String companynum;
	private String address;
	private String role;
	private LocalDateTime createdDate;
	 
	public MemberEntity toEntity() {
		MemberEntity memberEntity = MemberEntity.builder()
				 .mindex(mindex)
	             .id(id)
	             .pwd(pwd)
	             .name(name)
	             .phone(phone)
	             .email(email)
	             .companynum(companynum)
	             .address(address) 
	             .role(role)
	             .build();
		
		return memberEntity;
	}
}
