package com.academyinfo.member.dto;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@NoArgsConstructor
public class MemberResponseDto {
	// Member 관련 내용을  DB >> Entity >> Service 전달
		 private Long mindex;
		 
		 private String id;
		 private String pwd;
		 private String name;
		 private String phone;
		 private String email;
		 private String companynum;
		 private String address;
		 private String role;
		 private LocalDateTime createdDate;
		
		 @Builder
		 public MemberResponseDto(Long mindex, String id, String pwd, String name, String phone, String email, String companynum, String address, String role) {
		     this.mindex = mindex;
		     this.id = id;
		     this.pwd = pwd;
		     this.name = name;
		     this.phone = phone;
		     this.email = email;
		     this.companynum = companynum;
		     this.address = address;
		     this.role = role;
		 }
}
