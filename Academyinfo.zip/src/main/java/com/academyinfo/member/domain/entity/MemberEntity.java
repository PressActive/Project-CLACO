package com.academyinfo.member.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
@Table(name = "member")
public class MemberEntity {
	// 실제 테이블에 저장되어 있는 회원 데이터
	
    @Id 
    @Column(name = "mindex")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long mindex;
    
    @Column(length = 20, nullable = false)
    private String id;
    
    @Column(length = 100, nullable = false)
    private String pwd;
    
    @Column(length = 20, nullable = false)
    private String name;
    
    @Column(length = 20, nullable = false)
    private String phone;
    
    @Column(length = 30, nullable = false)
    private String email;
    
    @Column(length = 20)
    private String companynum;
    
    @Column(length = 50)
    private String address;
    
    @Column(length = 20)
    private String role;
    

    @Builder
    public MemberEntity(Long mindex, String id, String pwd, String name, String phone, String email, String companynum, String address, String role) {
        this.mindex = mindex;
        this.id = id;
        this.pwd = pwd;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.companynum = companynum;
        this.address = address;
        this.role = role;
    }
    
    /* 회원정보 수정 시 수정 가능한 데이터  */
    public void modify(String pwd, String phone, String email, String address) {
    this.pwd = pwd;
    this.phone = phone;
    this.email = email;
    this.address = address;
    }
}