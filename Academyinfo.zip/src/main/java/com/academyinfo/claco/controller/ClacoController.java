package com.academyinfo.claco.controller;

public interface ClacoController {
	
}
