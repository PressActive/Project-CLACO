(window.onload = function() {  // 화면이 뜬 뒤 처리

    	  var obj1 = document.getElementById('contents'); 
    	  var obj2 = document.getElementById('sidebar'); 
    	 
    	  var obj1_height = obj1.offsetHeight;
    	  var obj2_height = obj2.offsetHeight;

    	  if(obj1_height > obj2_height) { obj2.style.height = obj1_height + 'px'; }
    	  else { obj1.style.height = obj2_height + 'px'; }
    	})();
    	
$(document).ready(function(){
	
            $('.tabs li').click(function(){
                var tab_id = $(this).attr('data-tab');

                $('.tabs li').removeClass('current');
                $('.tab-content').removeClass('current');

                $(this).addClass('current');
                $("#"+tab_id).addClass('current');
            })

})

function isSame() {
        
        if(document.getElementById('update_pwd').value==document.getElementById('update_check').value) {
           document.getElementById('same').innerHTML='비밀번호가 일치합니다.';
           document.getElementById('same').style.color='blue';
        }
        else if(document.getElementById('update_pwd').value=='') {
			document.getElementById('same').innerHTML='';
		}
        
        else {
           document.getElementById('same').innerHTML='비밀번호가 일치하지 않습니다.';
           document.getElementById('same').style.color='red';
        }
}