package com.academyinfo.search.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

public interface TestController {
	// public String listMember(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception;
	public String testMain(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception;
	public String testFilter(Model model) throws Exception;
	public String testFilter_1(@RequestParam(value="keyword",required=false) String keyword, @RequestParam(value="arr_location_S", required=false) String[] arr_location_S, @RequestParam(value="arr_location_B", required=false) String[] arr_location_B, Model model ) throws Exception;
}
