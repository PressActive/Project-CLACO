package com.academyinfo.search.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.academyinfo.member.domain.MemberEntity;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor
@Table(name="academy")
public class AcademyEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer aindex;
	
	@Column
	private String name;
	
	@Column
	private double grade;
	
	@OneToOne
	@JoinColumn(name = "mindex")
	private MemberEntity mindex;
	
	@Column
	@OneToMany(mappedBy = "aindex", fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private List<ClassEntity> cindex;
	
	@Builder
	public AcademyEntity (Integer aindex, String name, double grade, MemberEntity mindex, List<ClassEntity> cindex) {
		this.aindex = aindex;
		this.name = name;
		this.grade = grade;
		this.mindex = mindex;
		this.cindex = cindex;
	}
}
