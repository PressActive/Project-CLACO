package com.academyinfo.search.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.academyinfo.search.domain.ImgEntity;
import com.academyinfo.search.repository.AcademyRepository;
import com.academyinfo.search.repository.ClassRepository;
import com.academyinfo.search.repository.ImgRepository;
import com.academyinfo.search.repository.ReviewRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service("MemberService")
public class TestServiceImpl implements TestService {
	private ImgRepository imgRepository;
	private ClassRepository classRepository;
	private ReviewRepository reviewRepository;
	private AcademyRepository academyRepository;
	
	/*
	//select * from member;
	public List listMember()
	{
		return memberRepository.findAll();
	}
	*/
	
	public List<ImgEntity> findByname(String name)
	{
		return imgRepository.findByName(name);
	}
	
	//select * from class;
	public List listClass()
	{
		return classRepository.findAll();
	}
	
	/*추천강의(c_status가 approval이면서 점수가 제일 높은 4개의 강의) - 강의내용*/
	public List selectRecommendedCourse()
	{
		return classRepository.selectRecommendedCourse();
	}
	/*추천강의(c_status가 approval이면서 점수가 제일 높은 4개의 강의) - 사진*/
	/*select * from imagefile;*/
	public List listImg()
	{
		return imgRepository.findAll();
	}
	
	//select * from review;
	public List listReview()
	{
		return reviewRepository.findAll();
	}
	
	/*최신 리뷰 순서로 정렬검색*/
	public List selectReview()
	{
		return reviewRepository.selectReview();
	}
	
	/*키워드검색*/
	public List findByKeyword(String keyword)
	{
		return classRepository.findByKeyword(keyword);
	}
	
	/*키워드와 서울지역 검색*/
	public List testFilter_S(String keyword, String[] arr_location_S)
	{
		return classRepository.testFilter_S(keyword, arr_location_S);
	}
	
	/*키워드와 부산지역 검색*/
	public List testFilter_B(String keyword, String[] arr_location_B)
	{
		return classRepository.testFilter_B(keyword, arr_location_B);
	}
}
