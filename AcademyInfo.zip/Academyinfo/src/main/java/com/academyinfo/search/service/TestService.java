package com.academyinfo.search.service;

import java.util.List;

import com.academyinfo.search.domain.ClassEntity;

public interface TestService {
	// public List listMember();
	public List findByname(String name);
	public List listClass();
	public List selectRecommendedCourse();
	public List listImg();
	public List listReview();
	public List selectReview();
	public List findByKeyword(String keyword);
	public List testFilter_S(String keyword, String[] arr_location_S);
	public List testFilter_B(String keyword, String[] arr_location_B);
}
