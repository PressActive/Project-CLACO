package com.academyinfo.search.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.academyinfo.search.domain.ClassEntity;
import com.academyinfo.search.service.TestService;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RequestMapping("/search")
@Controller("MemberController")
public class TestControllerImpl implements TestController{
	
	private TestService testService;
	
	/*
	@Override
	@RequestMapping("/detailInfo.do")
	public String listMember(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception
	{
		return "/search/detailInfo";
	}
	*/
	
	/*메인페이지*/
	@RequestMapping("/Main")
	public String testMain(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception
	{
		/*추천강좌카드*/
		List listImg = testService.listImg();
		List<ClassEntity> listClass = testService.selectRecommendedCourse();
		
		/*수강후기*/
		List listReview = testService.selectReview();
		
		/*추천강좌카드*/
		model.addAttribute("listImg", listImg);
		model.addAttribute("listClass",listClass);
		/*수강후기*/
		model.addAttribute("listReview",listReview);
		
		return "/search/testMain";
	}
	
	/*필터*/
	@RequestMapping("/Filter")
	public String testFilter(Model model) throws Exception
	{
		return "/search/testSearch";
	}
	
	/*필터 후 검색된 리스트*/
	@GetMapping("/keyword/search")
	public String testFilter_1(@RequestParam(value="keyword",required=false) String keyword, @RequestParam(value="arr_location_S", required=false) String[] arr_location_S, @RequestParam(value="arr_location_B", required=false) String[] arr_location_B, Model model ) throws Exception
	{
		List listFilter = null;
		//arr_location_S배열에 값이 있으면(서울체크박스가 선택된 경우)
		if(arr_location_S.length !=0)
		{
			//서울지역 SQL문이 실행
			listFilter = testService.testFilter_S(keyword, arr_location_S);	
		}
		//arr_location_B배열에 값이 있으면(부산체크박스가 선택된 경우)
		if(arr_location_B.length !=0)
		{
			//부산지역 SQL문이 실행
			listFilter = testService.testFilter_B(keyword, arr_location_B);
		}
		if(arr_location_S.length ==0 && arr_location_B.length ==0)
		{
			listFilter = testService.findByKeyword(keyword);
		}
		
		model.addAttribute("listFilter",listFilter);
		
		/*테스트용 코드*/
		for(int i = 0; i<arr_location_S.length; i++)
		{
			System.out.println(arr_location_S[i]);
		}
		
		for(int i = 0; i<arr_location_B.length; i++)
		{
			System.out.println(arr_location_B[i]);
		}
		/*테스트용 코드*/
		
		return "/search/testSearchList";
	}
	
}