package com.academyinfo.search.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor
@Table(name="class")
public class ClassEntity {
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cindex;
	
	@Column
	private String cname;
	
	@Column
	private String category;
	
	@Column
	private int price;
	
	@Column
	private double score;
	
	@Column(columnDefinition = "varchar(10) default 'limited'")
	private String cstatus;
	
	@Column
	private Date speriod;
	
	@Column
	private Date eperiod;
	
	@Column
	private String location;
	
	@Column
	private int grade;
	
	@Column
	private Integer iindex;
	
	@ManyToOne
	@JoinColumn(name = "aindex")
	private AcademyEntity aindex;
	
	// 잘되면 뺄 것
		@Column
		private String aname;
	
	@Builder
	public ClassEntity(Integer cindex, String cname, String category, int price, double score, String cstatus, Date speriod, Date eperiod, AcademyEntity aindex, String aname, String location, int grade, Integer iindex)
	{
		this.cindex = cindex;
		this.cname = cname;
		this.category = category;
		this.price = price;
		this.score = score;
		this.cstatus = cstatus;
		this.speriod = speriod;
		this.eperiod = eperiod;
		this.aindex = aindex;
		this.aname = aname;
		this.location = location;
		this.grade = grade;
		this.iindex = iindex;
	}
}
