package com.academyinfo.search.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor
@Table(name="review")
public class ReviewEntity {
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer rvindex;
	
	@Column
	private Date writedate;
	
	@Column
	private double score;
	
	@Column
	private String contents;
	
	@Column
	private int report;
	
	@Column
	private int mindex;
	
	@Column
	private String mid;
	
	@Column
	private int cindex;
	
	@Column
	private String cname;
	
	@Column
	private double cscore;

	@Builder
	public ReviewEntity(Integer rvindex, Date writedate, double score, String contents, int report, int mindex, String mid, int cindex, String cname, double cscore)
	{
		this.rvindex = rvindex;
		this.writedate = writedate;
		this.score = score;
		this.contents = contents;
		this.report = report;
		this.mindex = mindex;
		this.mid = mid;
		this.cindex = cindex;
		this.cname = cname;
		this.cscore = cscore;
	}
}
