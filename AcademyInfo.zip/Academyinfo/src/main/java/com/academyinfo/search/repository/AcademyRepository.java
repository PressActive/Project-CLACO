package com.academyinfo.search.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.academyinfo.search.domain.AcademyEntity;

public interface AcademyRepository extends JpaRepository<AcademyEntity, Integer> {

}
