package com.academyinfo.board.dto;

import java.time.LocalDateTime;

import com.academyinfo.board.domain.entity.BoardEntity;
import com.academyinfo.board.domain.entity.CommentEntity;
import com.academyinfo.member.domain.MemberEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class CommentRequestDto {
	private int cmtindex;
	private String comment;
	private LocalDateTime createdDate;
	private LocalDateTime modifiedDate;
	private BoardEntity bindex;
	private MemberEntity mid;
	
	// Dto to Entity
	public CommentEntity toEntity() {
		CommentEntity commentEntity = CommentEntity.builder()
				.cmtindex(cmtindex)
				.comment(comment)
				.createdDate(createdDate)
				.modifiedDate(modifiedDate)
				.bindex(bindex)
				.mid(mid)
				.build();
		
		return commentEntity;
	}
}
